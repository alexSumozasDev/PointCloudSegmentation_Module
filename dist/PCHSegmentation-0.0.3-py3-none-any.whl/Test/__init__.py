from Test.testOnlyMethods import testOnlyMethods
from Test.testAuto import testAuto
from Test.testDatabase import testDatabaseAdaptative, testDatabase